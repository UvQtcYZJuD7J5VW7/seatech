close all ; clear all ;

%% Paramétrage
trameLength = 5000 ; % Nombre d'échantillons d'une trame
sampleRate = 8000 ; % Taux d'échantillonage pour le fichier audio de sortie (Hz)
freqResponseN = 500 ; % Nombre de point pour le calcul de la réponse fréquentielle
P = 10 ; % Ordre de prédiction
maxlag = 100 ;
gamma = 30 ;
sigma = 30 ;

%% Initialisation des vecteurs de travail
input = audioread("meteo.wav")' ; % Lecture du fichier audio
output = [] ; % Initalisation du vecteur de sortie

%% Traitement et filtrage du signal d'entrée
for i = 1 : trameLength : length(input)
    borneInf = i ; % Définition de la borne inférieure de la trame
    borneSup = min(i + trameLength - 1,length(input)) ; % Définition de la borne supérieure de la trame

    %% Segmentation en trame
    trame = input(:,borneInf:borneSup) ; % Trame de travail

    %% Réponse fréquentielle de la trame
    [H,w] = freqz(trame,1,freqResponseN) ;
    H = abs(H) ;
    w = w/(2*pi) ;

    %% Prédiction des coefficients
    A = lpc(trame,P) ;
    [HA,wA] = freqz(1,A,freqResponseN) ;
    HA = abs(HA) ;
    wA = wA/(2*pi) ;

    figure(8)
    RCT = HA * trame ;
    plot([1 : length(RCT)],RCT)

    %% Affichage de la trame
    figure(1)
    subplot(3,2,3)
    hold on
    plot([borneInf : borneSup],trame)
    subplot(3,2,4)
    hold on
    plot(w,H)

    %% Concaténation des trames
    output = [output , trame ] ;
end

%% Réponse fréquentielle du signal d'entrée
[Hinput,winput] = freqz(input,1,500) ;
Hinput = abs(Hinput) ;
winput = winput/(2*pi) ;
[Houtput,woutput] = freqz(output,1,500) ;
Houtput = abs(Houtput) ;
woutput = woutput/(2*pi) ;

%% Génération du fichier audio de sortie
audiowrite("plop.wav",output,sampleRate) ;

%% Affichage
figure(1) % Réprésentation du input d'entrée et de ses segments
subplot(3,2,1)
plot([1 : 1 : length(input)],input)
title("Forme d'onde - Signal d'entrée")
subplot(3,2,2)
plot(winput,Hinput)
title("Spectre - Signal d'entrée")
subplot(3,2,3)
title("Forme d'onde - Trames")
subplot(3,2,4)
title("Spectre - Trames")
subplot(3,2,5)
plot([1 : 1 : length(output)],output)
title("Forme d'onde - Signal de sortie")
subplot(3,2,6)
plot(woutput,Houtput)
title("Spectre - Signal de sortie")

